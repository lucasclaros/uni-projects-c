#define QUEUES 4

typedef enum priorities { ELDERLY_1, NORMAL_1, ELDERLY_0, NORMAL_0 } prio;
typedef enum bool { FALSE, TRUE } bool;
typedef struct Queue queue_t;

typedef struct Commands
{
    int nLines;
    char **linesInput;
    queue_t *main_queue[QUEUES];
} commands_t;

typedef struct Person
{
    char *name;
    int prio, age;
} person_t;

char *read_line(); 
void commandsDecider (commands_t *);
int  queueNext       (commands_t *);
int  queueAppend     (commands_t *, int);