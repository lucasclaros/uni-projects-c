#define SIZE_QUEUE 100

typedef struct Queue { 
    int ini, end, total;
    void *queue[SIZE_QUEUE];
} queue_t;

queue_t *queueCreate();
void queueDestroy (queue_t *);
void *queueRemove (queue_t *);
int  queueisFull  (queue_t *);
int  queueisEmpty (queue_t *);
int  queueInsert  (queue_t *, void *);