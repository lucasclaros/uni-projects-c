#include "queue.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

queue_t *queueCreate(){
    queue_t *p = (queue_t *)malloc(sizeof(queue_t));
    assert(p != NULL);
    p->ini = 0;
    p->end = 0;
    p->total = 0;
    return p; 
}

void queueDestroy(queue_t *p){
    if(p != NULL) free(p);
}

int queueisFull(queue_t *p){
    assert(p != NULL);

    if (p->total < SIZE_QUEUE-1)
        return 0;
    return 1;
}

int queueisEmpty(queue_t *p){
    assert(p != NULL);

    if (p->total == 0)
        return 1;
    return 0;
}

int queueInsert(queue_t *p, void *x){
    assert(p != NULL);

    if(queueisFull(p) == 1)
        return -1;

    p->total++;
    p->queue[p->end] = x;
    p->end = (p->end+1) % SIZE_QUEUE;
    return 1;
}

void *queueRemove(queue_t *p){
    assert(p != NULL);
    assert(queueisEmpty(p) != 1);

    p->total--;
    void *value = p->queue[p->ini];
    p->ini = (p->ini+1) % SIZE_QUEUE;
    return value;
}