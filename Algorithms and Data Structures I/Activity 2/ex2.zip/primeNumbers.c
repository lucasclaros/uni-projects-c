#include "list.h"
#include "primeNumbers.h"
#include <stdio.h>
#include <stdlib.h>

int *readIndexes(int nIndexes){
    int *v = malloc(nIndexes * sizeof(int));
    for (int i = 0; i < nIndexes; i++)
        scanf(" %d", &v[i]);
    return v;
}

void primesCalculate(list_t *l){
    initiateValues(l, MAX_SIZE_LIST);
    listRemoveMultiples(l);
}

void initiateValues(list_t *l, int maxNumber){
    for (int i = 2; i < maxNumber; i++)
        listInsert(l, i);
}

int isMultiple(int n1, int n2){
    if ((n1 % n2 == 0) && n1 != n2)
        return 1;
    return 0;
}