
typedef struct List list_t;

int *readIndexes(int nIndexes);
void primesCalculate(list_t *l);
void initiateValues(list_t *l, int maxNumber);
int isMultiple(int, int);