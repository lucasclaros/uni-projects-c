typedef struct List list_t;

int readInputs(list_t *l);