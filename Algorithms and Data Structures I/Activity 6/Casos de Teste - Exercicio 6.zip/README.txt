Arquivo zip gerado em: 09/10/2021 20:10:23 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 6