Arquivo zip gerado em: 12/12/2021 16:39:41 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 10