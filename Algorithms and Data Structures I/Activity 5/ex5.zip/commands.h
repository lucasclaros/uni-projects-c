#define SIZE_OPENERS 3

typedef enum bool { FALSE, TRUE } bool;
typedef struct stack stack_t;

bool checkOpener(char c);
bool checkLast(char c, int index);
int checkFinisher(char c);
void checkSequence(stack_t *);
char *read_line(bool *isEOF);