#include <stdio.h>
#include <stdlib.h>
#include "commands.h"
#include "stack.h"

char openers[SIZE_OPENERS] = "({[";
char finishers[SIZE_OPENERS] = ")}]";

bool checkOpener(char c){
    bool result = FALSE;
    for (int i = 0; i < SIZE_OPENERS; i++)
        if(c == openers[i])
            result = TRUE;
    return result;
}

int checkFinisher(char c){
    for (int i = 0; i < SIZE_OPENERS; i++)
        if(c == finishers[i])
            return i;
    return -1;
}

bool checkLast(char c, int index){
    if(c == openers[index])
        return TRUE;
    return FALSE;
}


void checkSequence(stack_t *s){
    if(isEmpty(s))
        printf("BALANCEADO\n");
    else
        printf("NÃO BALANCEADO\n");
}

char *read_line(bool *isEOF){
    int c,k=0;
    char *linha = NULL;
    while((c=getchar()) != '\n' && c != EOF)
    {
        if (c == '\r' || c == ' ') continue;
        
        linha = realloc(linha, (k+1) * sizeof(char));
        linha[k++] = c;
    }
    if (c == EOF) *isEOF = TRUE;
    linha = realloc(linha, (k+1) * sizeof(char));
    linha[k] = '\0';
    return linha;
}

