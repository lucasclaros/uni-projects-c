#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "minesweeper.h"



char *read_line(){
    char *line = NULL;
    int c, k = 0;
    while(( c = getchar()) != '\n')
    {
        line = realloc(line, (k+1) * sizeof(char));
        line[k++] = c;
    }
    line = realloc(line, (k+1) * sizeof(char));
    line[k] = '\0';
    return line;
}

char *read_line_file(FILE *file, int *isEOF){
    char *line = NULL, c;
    int k = 0; // letters
    while ((c = fgetc(file)) != '\n')
    {
        line = (char *)realloc(line, ((k+1) * sizeof(char)));
        line[k++] = c;
    }
    if ((c = fgetc(file)) == EOF) *isEOF = 1;
    else ungetc(c, file);
    line = (char *)realloc(line, ((k+1) * sizeof(char)));
    line[k] = '\0';
    return line;
}

void print_board(board_t *board, int board_option){
    for (int i = 0; i < board->lines; i++)
    {
        printf("%s", board->matrix[board_option][i]);
        if (i+1 < board->lines)
            printf("\n"); 
    }
}

void read_board(board_t *board){
    FILE *file = fopen(board->name, "r");
    for (board->lines = 0; board->isEOF != 1; board->lines++)
    {
        board->matrix[HINTS_BOARD] = (char **) realloc(board->matrix[HINTS_BOARD], (board->lines+1) * sizeof(char *));
        board->matrix[HINTS_BOARD][board->lines] = NULL;
        board->matrix[HINTS_BOARD][board->lines] = read_line_file(file, &board->isEOF);
    }
    board->width = strlen(board->matrix[HINTS_BOARD][0]);
    fclose(file);
}

void load_hints(board_t *board){
    int maxIndex = board->lines * board->width;
    for (int index=0; index < maxIndex; index++)
    {
        int row = index / board->width;
        int col = index % board->width;
            if (board->matrix[HINTS_BOARD][row][col] == BOMB)
                check_neighbors(board, row, col);  
    }
}

void check_neighbors(board_t *board, int posY, int posX){

    for (int i = 0; i < BORDERS; i++)
    {
        int neighborY = posY + board->offsetsY[i];
        int neighborX = posX + board->offsetsX[i];
        if
        (    
            neighborY < 0 || neighborY > (board->lines-1) ||
            neighborX < 0 || neighborX > (board->width-1)
        )
        {
            continue;
        }
        char position = board->matrix[HINTS_BOARD][neighborY][neighborX];
        if (position == BLANK_SPACE)
            board->matrix[HINTS_BOARD][neighborY][neighborX] = '1';
        else if (position == BOMB)
            continue;
        else
        {
            int neighbor = board->matrix[HINTS_BOARD][neighborY][neighborX] - '0';
            neighbor++;
            board->matrix[HINTS_BOARD][neighborY][neighborX] = neighbor + '0';
        } 
    }
}

void player_move(board_t *board){
    scanf("%d %d", &board->posY, &board->posX);
    getchar();

    load_hints(board);

    char position = board->matrix[HINTS_BOARD][board->posY][board->posX];
    if (position == BOMB)
        print_board (board, HINTS_BOARD);
    else if (position == BLANK_SPACE)
    {
        prepare_board(board);
        fill_board(board, board->posY, board->posX);
        print_board (board, USER_BOARD);
    }
    else
    {
        prepare_board(board);
        board->matrix[USER_BOARD][board->posY][board->posX] = board->matrix[HINTS_BOARD][board->posY][board->posX];
        print_board (board, USER_BOARD);
    }
}

void prepare_board(board_t *board){
    board->matrix = realloc(board->matrix, (board->boards+1)*sizeof(char**));
    board->boards++;
    board->matrix[USER_BOARD] = malloc(board->lines * sizeof(char *));

    int i,j;
    for (i = 0; i < board->lines; i++)
    {
        board->matrix[USER_BOARD][i] = malloc((board->width+1) * sizeof(char));
        for (j = 0; j < board->width; j++)
            board->matrix[USER_BOARD][i][j] = 'X';
        board->matrix[USER_BOARD][i][j] = '\0';
    }
}

void fill_board(board_t *board, int posY, int posX){
    board->matrix[USER_BOARD][posY][posX] = board->matrix[HINTS_BOARD][posY][posX];   

    if(board->matrix[HINTS_BOARD][posY][posX] != BLANK_SPACE)
        return;

    for (int i = 0; i < BORDERS; i++)
    {
        int neighborY = posY + board->offsetsY[i];
        int neighborX = posX + board->offsetsX[i];
        if
        (    
            neighborY < 0 || neighborY > (board->lines-1) ||
            neighborX < 0 || neighborX > (board->width-1) ||
            board->matrix[USER_BOARD][neighborY][neighborX] != UNREVEALED
        ) continue;
        fill_board(board, neighborY, neighborX);
    }
}

board_t *initialize_board(){
    board_t *board = (board_t *) malloc(1 * sizeof(board_t));
    assert(board != NULL);
    board->offsetsX = (int *) malloc(BORDERS * sizeof(int));
    assert(board->offsetsX != NULL);
    board->offsetsY = (int *) malloc(BORDERS * sizeof(int));
    assert(board->offsetsY != NULL);
    board->matrix   = (char ***) malloc(sizeof(char **));
    assert(board->matrix != NULL);
    board->boards = 1;
    board->isEOF = 0;
    board->matrix[0] = NULL;
    board->name = NULL;

    int offsety[] = {-1,-1,-1, 0, 0, 1, 1, 1};
    int offsetx[] = {-1, 0, 1,-1, 1,-1, 0, 1};
    for (int i = 0; i < BORDERS; i++)
    {
        board->offsetsY[i] = offsety[i];
        board->offsetsX[i] = offsetx[i];
    }
    return board;
}

void destroy_all(board_t *board){
    for (int i = 0; i < board->boards; i++)
    {
        for (int j = 0; j < board->lines; j++)
            free(board->matrix[i][j]);
        free(board->matrix[i]);
    }
    free(board->offsetsX);
    free(board->offsetsY);
    free(board->matrix);
    free(board->name);
    free(board);
}