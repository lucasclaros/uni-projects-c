/**
 *   Author: Lucas da Silva Claros
 *   nUSP: 12682592
 *   Create Time: 15/09/2021 22:35
 *   Modified time: 15/09/2021 22:56
 *   Description: Minesweeper Header
 */

#define BLANK_SPACE '.'
#define BOMB        '*'
#define UNREVEALED  'X'
#define BORDERS      8
#define HINTS_BOARD  0
#define USER_BOARD   1

typedef struct board
{
    char *name, ***matrix;
    int isEOF, lines, width, posY, posX, boards;
    int *offsetsX, *offsetsY;
} board_t;

board_t *initialize_board();
char *read_line();
char *read_line_file (FILE *, int *);
void destroy_all     (board_t *);
void read_board      (board_t *);
void print_board     (board_t *, int);
void check_neighbors (board_t *, int, int);
void load_hints       (board_t *);
void prepare_board   (board_t *);
void player_move     (board_t *);
void fill_board      (board_t *, int, int);